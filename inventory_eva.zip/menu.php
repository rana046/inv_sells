<?php
include 'header.php';
?>
<body>

<div id='cssmenu' style="margin-left:0px; margin-top: 0px;width:100%;">
<ul>

   <li><a href='home.php'><span>Home</span></a></li>
   <li><a href='inventory.php'><span>Dealer Stock</span></a></li>
   <li><a href='#'><span>Dealer Sells</span></a></li>
   <li><a href='#'><span>Account</span></a>
   	<ul style="display:block;">
        <li class='has-sub'><a href='#'><span>Sells Account</span></a>
            
         </li>
         <li class='has-sub'><a href='#'><span>Stock Account</span></a>
            
         </li>
         <li class='has-sub'><a href='#'><span>Daily Account </span></a>
            
         </li>
         <li class='has-sub'><a href='#'><span>Total Account</span></a>
            
         </li>
      </ul>
      <li class='last'><a href='#'><span>LONE/LEND</span></a></li>
      <li class='last'><a href='#'><span>IMPORT</span></a></li>

   </li>
   <li class='last'><a href='#'><span>Export</span></a></li>

   
   
</ul>
</div>

</body>
<html>
