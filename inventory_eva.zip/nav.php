<!doctype >
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/stylesnav.css">
   
   <title>nav</title>
</head>
<body>

        <div id='menucss' style="height:initial;">
         <ul>
            <li><a href='home.php'><span>Home</span></a></li>
            <li><a href='#'><span>Import</span></a></li>
            <li><a href='stock.php'><span>Stock</span></a></li>
            <li><a href='sells.php'><span>Sell Product</span></a></li>
            <li><a href='#'><span>Export</span></a></li>
            <li><a href='#'><span>Lend/Loan</span></a></li>
            <li style="float:right;"><a class='last' href='index.php'><span>Logout</span></a></li>
            <li ><a href='#'><span></span></a></li>
         </ul>
   </div>
         

</body>
<html>
