<?php
$servername = "localhost";
$username = "root";
$password = "";
$myDB = "sells";

// Create connection
$conn = new mysqli($servername, $username, $password,$myDB);

?>